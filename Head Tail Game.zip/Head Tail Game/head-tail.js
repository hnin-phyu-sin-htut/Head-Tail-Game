const score = JSON.parse(localStorage.getItem('score')) || {
  wins: 0,
  losses: 0,
  ties: 0
};

updateScoreElement();

function playGame(playerMove){
  const computerMove = pickComputerMove();
  let result = '';

  if(playerMove === 'head'){
    if(computerMove === 'head'){
      result = 'You win';
    }else if(computerMove === 'tail'){
      result = 'You lose';
    }
  }else if(playerMove === 'tail'){
    if(computerMove === 'head'){
      result = 'You lose';
    }else if(computerMove === 'tail'){
      result = 'You win';
    }
  }

  if(result === 'You win'){
    score.wins++;
  }else if(result === 'You lose'){
    score.losses++;
  }

  localStorage.setItem('score', JSON.stringify(score));

  updateScoreElement();

  document.querySelector('.js-result').innerHTML = result;
  document.querySelector('.js-moves').innerHTML = `
    You
      <img class="move-icon" src="images/${playerMove}-coin.png">
      <img class="move-icon" src="images/${computerMove}-coin.png">
    Computer
  `;
}

function updateScoreElement(){
  document.querySelector('.js-score').innerHTML = `
    Wins: ${score.wins}, Losses: ${score.losses}
  `;
}

function pickComputerMove(){
  const randomNumber = Math.random();
  let computerMove = '';

  if(randomNumber >= 0 && randomNumber < 1/2){
    computerMove = 'head';
  }else if(randomNumber >= 1/2 && randomNumber < 1){
    computerMove = 'tail';
  }
  return computerMove;
}